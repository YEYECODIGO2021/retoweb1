package com.retoweb.uno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
