package com.retoweb.uno.reposy;

import java.util.List;
import java.util.Optional;

import com.retoweb.uno.crud.UserCrud;
import com.retoweb.uno.modelo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RepoUser {

    @Autowired
    private UserCrud userCrud;
    
    public List<User> getUsuarios(){
        return (List<User>) userCrud.findAll();
    }

    public Optional<User> getUsuario(int id){
        return userCrud.findById(id);
    }
    
    public User guardar(User userNuevo){
        return userCrud.save(userNuevo);
    }
    public Boolean existeCorreo(String correo){
        Optional<User> usuario = userCrud.findByEmail(correo);
        return !usuario.isEmpty();
    }

    public Optional<User> validarUsuarios(String correo,String clave){
        return userCrud.findByEmailAndPassword(correo, clave);
    }


    
    }
