package com.retoweb.uno.crud;

import java.util.Optional;
import com.retoweb.uno.modelo.User;
import org.springframework.data.repository.CrudRepository;

public interface UserCrud extends CrudRepository<User,Integer>{

    Optional<User> findByEmail(String correo);
    Optional<User> findByEmailAndPassword(String correo,String clave);

}