package com.retoweb.uno.modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
@NoArgsConstructor
@Table(name= "user", indexes = @Index(name="ind_email", columnList = "userCorreo", unique = true))
public class User implements Serializable{
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @NonNull
    @Column(name="userCorreo", nullable = false, length = 50)
    private String email;
    @NonNull
    @Column(name = "ContraseñaUsuario", nullable = false, length = 50)
    private String password;
    @NonNull
    @Column(name = "NombresUsuario", nullable = false, length = 50)
    private String name;
  

    public User() {
    }
    public User(String email,String password,String name) {
        this.password = password;
        this.email = email;
        this.name = name;
    }
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }


    
}
