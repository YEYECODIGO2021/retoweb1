package com.retoweb.uno.servicio;

import java.util.List;
import java.util.Optional;

import com.retoweb.uno.modelo.User;
import com.retoweb.uno.reposy.RepoUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServicioUsuario {
    
    @Autowired
    private RepoUser repoUser;

    public List<User> getRegistroUser(){
        return repoUser.getUsuarios();
    }

    public Optional<User> getRegistroId(int id){
        return repoUser.getUsuario(id);
    }

    public User registrarNuevo(User userNuevo){
        if(userNuevo.getId()== null){
            if(existeCorreo(userNuevo.getEmail()) == false){
                return repoUser.guardar(userNuevo);
            }else{
                return userNuevo;
            }
        }else{
            return userNuevo;
        }
    }
    public boolean existeCorreo(String correo){
        return repoUser.existeCorreo(correo);
    }

    public User validarUsuario(String correo, String clave){
        Optional<User> nuevoDato = repoUser.validarUsuarios(correo, clave);
        if(nuevoDato.isEmpty()){
            return new User(correo,clave,"NO DEFINIDO");
        }else{
            return nuevoDato.get();
        }
    }

    
}
