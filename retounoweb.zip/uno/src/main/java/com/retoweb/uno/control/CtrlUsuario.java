package com.retoweb.uno.control;

import java.util.List;
import com.retoweb.uno.modelo.User;
import com.retoweb.uno.servicio.ServicioUsuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
@CrossOrigin("*")
public class CtrlUsuario {

@Autowired
private ServicioUsuario servicioUsuario;

@GetMapping("/all")
public List<User> getDatosUser(){
    return servicioUsuario.getRegistroUser();
}

@PostMapping("/new")
@ResponseStatus( HttpStatus.CREATED)
public User saveNuevoDato(@RequestBody User userNuevo){
    return servicioUsuario.registrarNuevo(userNuevo);
}

@GetMapping("/{email}/{password}")
public User validarLogin(@PathVariable ("email") String correo,@PathVariable("password") String clave){
    return servicioUsuario.validarUsuario(correo, clave);
}
@GetMapping(value="/{email}")
public  boolean searchCorreo(@PathVariable ("email") String correo) {
    return servicioUsuario.existeCorreo(correo);
}





    
}
